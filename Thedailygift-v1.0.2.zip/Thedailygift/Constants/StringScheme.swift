import UIKit

struct StringConstants {
    static let k: String = ""
    static let kMsgDo2PagesCoun: String = "Do 2 pages count ...?"
    static let kMsgPaySomeoneA: String = "Pay someone a \ngenuine compliment \ntoday!"
    static let kMsgDoneAndDusted: String = "Done and dusted!"
    static let kLblYesYum: String = "Yes, yum."
    static let kMsgDoSomethingOu: String =
        "Do something out of \nyour comfort zone. \n\nA tiny leap for mankind. A huge step for you."
    static let kMsgCountryRoads: String = "Country roads, take me home."
    static let kMsgHungryFriendF: String = "Hungry friend fed!"
    static let kMsgStartANewBoo: String = "Start a new book today."
    static let kLblISurvived: String = "I survived."
    static let kMsgBeAHeroToA: String = "Be a hero to a\n hungry friend today.\nLunch treat!"
    static let kMsgDevote30Mins: String =
        "Devote 30 mins to yoga.\nYour future self \nwill thank you."
    static let kLblOhmmmmmm: String = "OHMMMMMM."
    static let kHttpFail: String = "HTTP request failed"
    static let kMsgGivingIsAsGo: String = "Giving is as good as it gets.\nTo yourself or others."
    static let kMsgHaveAFruitTh: String = "Have a fruit that you \nhaven’t tried before!"
    static let kUnableToFetch: String = "Unable to fetch data"
    static let kLblOpenSesame: String = "Open sesame."
    static let kMsgTreatYourself: String = "Treat yourself to a \nreally good meal today."
    static let kMsgTriedItLike: String = "Tried it,  liked it."
    static let kLblDay6: String = "Day 6"
    static let kLblDay7: String = "Day 7"
    static let kLblDay4: String = "Day 4"
    static let kLblDay5: String = "Day 5"
    static let kLblDay2: String = "Day 2"
    static let kLblDay3: String = "Day 3"
    static let kInvalidUrl: String = "Invalid URL"
    static let kLblTheDailyGift: String = "The daily gift"
    static let kLblDay1: String = "Day 1"
    static let kMsgSurpriseMeTod: String = "Surprise me today!"
}
