//
//  AppConstants.swift
//  Thedailygift

import Foundation

struct AppConstants {
    static let serverURL: String = "@{serverURL}"
}
