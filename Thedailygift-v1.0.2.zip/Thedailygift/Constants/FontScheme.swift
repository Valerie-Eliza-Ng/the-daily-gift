import Foundation
import SwiftUI

class FontScheme: NSObject {
    static func kAbelRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kAbelRegular, size: size)
    }

    static func kManropeRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kManropeRegular, size: size)
    }

    static func kManropeBold(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kManropeBold, size: size)
    }

    static func fontFromConstant(fontName: String, size: CGFloat) -> Font {
        var result = Font.system(size: size)

        switch fontName {
        case "kAbelRegular":
            result = self.kAbelRegular(size: size)
        case "kManropeRegular":
            result = self.kManropeRegular(size: size)
        case "kManropeBold":
            result = self.kManropeBold(size: size)
        default:
            result = self.kAbelRegular(size: size)
        }
        return result
    }

    enum FontConstant {
        /**
         * Please Add this fonts Manually
         */
        static let kAbelRegular: String = "Abel-Regular"
        /**
         * Please Add this fonts Manually
         */
        static let kManropeRegular: String = "Manrope-Regular"
        /**
         * Please Add this fonts Manually
         */
        static let kManropeBold: String = "Manrope-Bold"
    }
}
