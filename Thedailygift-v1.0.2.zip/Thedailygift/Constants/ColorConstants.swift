import SwiftUI

struct ColorConstants {
    static let Bluegray900: Color = .init("Bluegray900")
    static let OrangeA200: Color = .init("OrangeA200")
    static let Gray900: Color = .init("Gray900")
    static let Red300: Color = .init("Red300")
    static let Yellow50: Color = .init("Yellow50")
    static let Black90019: Color = .init("Black90019")
    static let WhiteA700: Color = .init("WhiteA700")
    static let Orange300: Color = .init("Orange300")
    static let Gray50: Color = .init("Gray50")
}
