import SwiftUI

struct DayOneView: View {
    @StateObject var dayOneViewModel = DayOneViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack(alignment: .leading, spacing: 0) {
                    VStack(alignment: .leading, spacing: 0) {
                        Image("img_comboshape")
                            .resizable()
                            .frame(width: getRelativeWidth(20.0), height: getRelativeWidth(20.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.horizontal, getRelativeWidth(26.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(20.0),
                           alignment: .leading)
                    VStack {
                        ZStack(alignment: .leading) {
                            VStack {
                                Text(StringConstants.kLblDay1)
                                    .font(FontScheme.kAbelRegular(size: getRelativeHeight(36.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Red300)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(74.0),
                                           height: getRelativeHeight(36.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(25.0))
                                Text(StringConstants.kMsgTreatYourself)
                                    .font(FontScheme.kManropeRegular(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Bluegray900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(262.0),
                                           height: getRelativeHeight(54.0), alignment: .center)
                                    .padding(.top, getRelativeHeight(146.0))
                                VStack {
                                    Text(StringConstants.kLblYesYum)
                                        .font(FontScheme
                                            .kManropeBold(size: getRelativeHeight(18.0)))
                                        .fontWeight(.bold)
                                        .foregroundColor(ColorConstants.WhiteA700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(83.0),
                                               height: getRelativeHeight(18.0),
                                               alignment: .topLeading)
                                        .padding(.vertical, getRelativeHeight(22.0))
                                        .padding(.horizontal, getRelativeWidth(64.0))
                                }
                                .onTapGesture {
                                    dayOneViewModel.nextScreen = "Confirmation1View"
                                }
                                .frame(width: getRelativeWidth(211.0),
                                       height: getRelativeHeight(56.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                           bottomLeft: 20.0, bottomRight: 20.0)
                                        .fill(ColorConstants.Red300))
                                .padding(.top, getRelativeHeight(151.0))
                                .padding(.horizontal, getRelativeWidth(25.0))
                            }
                            .frame(width: getRelativeWidth(262.0), height: getRelativeHeight(445.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(48.99))
                            .padding(.bottom, getRelativeHeight(47.01))
                            .padding(.horizontal, getRelativeWidth(33.0))
                            VStack {
                                Text(StringConstants.kLblDay1)
                                    .font(FontScheme.kAbelRegular(size: getRelativeHeight(36.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Red300)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(74.0),
                                           height: getRelativeHeight(36.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(48.0))
                                    .padding(.horizontal, getRelativeWidth(33.0))
                                Text(StringConstants.kMsgTreatYourself)
                                    .font(FontScheme.kManropeRegular(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Bluegray900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(262.0),
                                           height: getRelativeHeight(54.0), alignment: .center)
                                    .padding(.top, getRelativeHeight(146.0))
                                    .padding(.horizontal, getRelativeWidth(33.0))
                                Button(action: {}, label: {
                                    HStack(spacing: 0) {
                                        Text(StringConstants.kLblYesYum)
                                            .font(FontScheme
                                                .kManropeBold(size: getRelativeHeight(18.0)))
                                            .fontWeight(.bold)
                                            .padding(.horizontal, getRelativeWidth(30.0))
                                            .padding(.vertical, getRelativeHeight(19.0))
                                            .foregroundColor(ColorConstants.WhiteA700)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.center)
                                            .frame(width: getRelativeWidth(211.0),
                                                   height: getRelativeHeight(56.0),
                                                   alignment: .center)
                                            .background(RoundedCorners(topLeft: 20.0,
                                                                       topRight: 20.0,
                                                                       bottomLeft: 20.0,
                                                                       bottomRight: 20.0)
                                                    .fill(ColorConstants.Red300))
                                            .padding(.vertical, getRelativeHeight(151.0))
                                            .padding(.horizontal, getRelativeWidth(33.0))
                                    }
                                })
                                .frame(width: getRelativeWidth(211.0),
                                       height: getRelativeHeight(56.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                           bottomLeft: 20.0, bottomRight: 20.0)
                                        .fill(ColorConstants.Red300))
                                .padding(.vertical, getRelativeHeight(151.0))
                                .padding(.horizontal, getRelativeWidth(33.0))
                            }
                            .frame(width: getRelativeWidth(327.0), height: getRelativeHeight(541.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                    bottomRight: 20.0)
                                    .stroke(ColorConstants.Red300,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                       bottomLeft: 20.0, bottomRight: 20.0)
                                    .fill(ColorConstants.WhiteA700))
                            .shadow(color: ColorConstants.Black90019, radius: 35, x: 0, y: 12)
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(327.0), height: getRelativeHeight(541.0),
                               alignment: .center)
                        .overlay(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                bottomRight: 20.0)
                                .stroke(ColorConstants.Red300,
                                        lineWidth: 1))
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.WhiteA700))
                        .shadow(color: ColorConstants.Black90019, radius: 35, x: 0, y: 12)
                        .padding(.horizontal, getRelativeWidth(24.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(541.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(18.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Image("img_longerdesign")
                            .resizable()
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(167.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(167.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(19.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.OrangeA200)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: OnboardView(),
                                   tag: "OnboardView",
                                   selection: $dayOneViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: Confirmation1View(),
                                   tag: "Confirmation1View",
                                   selection: $dayOneViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.OrangeA200)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
        .onAppear {
            dayOneViewModel.nextScreen = "OnboardView"
        }
    }
}

struct DayOneView_Previews: PreviewProvider {
    static var previews: some View {
        DayOneView()
    }
}
