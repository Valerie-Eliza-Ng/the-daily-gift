import Foundation
import SwiftUI

class DayOneViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
