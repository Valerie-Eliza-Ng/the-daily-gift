import Foundation
import SwiftUI

class DayTwoViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
