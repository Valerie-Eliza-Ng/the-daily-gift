import Foundation
import SwiftUI

class Confirmation4ViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
