import SwiftUI

struct DaySixView: View {
    @StateObject var daySixViewModel = DaySixViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    HStack {
                        ZStack(alignment: .bottomLeading) {
                            Image("img_comboshape")
                                .resizable()
                                .frame(width: getRelativeWidth(20.0),
                                       height: getRelativeWidth(20.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Image("img_comboshape_20x20")
                                .resizable()
                                .frame(width: getRelativeWidth(20.0),
                                       height: getRelativeWidth(20.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                        }
                        .hideNavigationBar()
                    }
                    .frame(width: getRelativeWidth(20.0), height: getRelativeHeight(22.0),
                           alignment: .leading)
                    .padding(.leading, getRelativeWidth(6.0))
                    .padding(.trailing, getRelativeWidth(10.0))
                    VStack(alignment: .trailing, spacing: 0) {
                        VStack {
                            Text(StringConstants.kLblDay6)
                                .font(FontScheme.kAbelRegular(size: getRelativeHeight(36.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Red300)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(71.0),
                                       height: getRelativeHeight(36.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(43.0))
                                .padding(.horizontal, getRelativeWidth(114.0))
                            Text(StringConstants.kMsgDoSomethingOu)
                                .font(FontScheme.kManropeRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Bluegray900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(261.0),
                                       height: getRelativeHeight(144.0), alignment: .center)
                                .padding(.top, getRelativeHeight(55.0))
                                .padding(.horizontal, getRelativeWidth(31.0))
                            Button(action: {
                                daySixViewModel.nextScreen = "ConfirmationView"
                            }, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLblISurvived)
                                        .font(FontScheme
                                            .kManropeBold(size: getRelativeHeight(18.0)))
                                        .fontWeight(.bold)
                                        .padding(.horizontal, getRelativeWidth(30.0))
                                        .padding(.vertical, getRelativeHeight(12.0))
                                        .foregroundColor(ColorConstants.WhiteA700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: getRelativeWidth(194.0),
                                               height: getRelativeHeight(43.0), alignment: .center)
                                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                                   bottomLeft: 20.0,
                                                                   bottomRight: 20.0)
                                                .fill(ColorConstants.Gray900))
                                        .padding(.vertical, getRelativeHeight(53.0))
                                        .padding(.horizontal, getRelativeWidth(31.0))
                                }
                            })
                            .frame(width: getRelativeWidth(194.0), height: getRelativeHeight(43.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                       bottomLeft: 20.0, bottomRight: 20.0)
                                    .fill(ColorConstants.Gray900))
                            .padding(.vertical, getRelativeHeight(53.0))
                            .padding(.horizontal, getRelativeWidth(31.0))
                        }
                        .frame(width: getRelativeWidth(325.0), height: getRelativeHeight(421.0),
                               alignment: .center)
                        .overlay(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                bottomRight: 20.0)
                                .stroke(ColorConstants.Red300,
                                        lineWidth: 1))
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.WhiteA700))
                        .shadow(color: ColorConstants.Black90019, radius: 35, x: 0, y: 12)
                        .padding(.horizontal, getRelativeWidth(6.0))
                        Image("img_appforjacob_282x335")
                            .resizable()
                            .frame(width: getRelativeWidth(335.0), height: getRelativeHeight(282.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.top, getRelativeHeight(18.0))
                    }
                    .frame(width: getRelativeWidth(335.0), height: getRelativeHeight(721.0),
                           alignment: .leading)
                    .background(ColorConstants.Red300)
                    .padding(.top, getRelativeHeight(25.0))
                }
                .frame(width: getRelativeWidth(335.0), alignment: .topLeading)
                .background(ColorConstants.Red300)
                .padding(.top, getRelativeHeight(47.0))
                .padding(.horizontal, getRelativeWidth(20.0))
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: ConfirmationView(),
                                   tag: "ConfirmationView",
                                   selection: $daySixViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Red300)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct DaySixView_Previews: PreviewProvider {
    static var previews: some View {
        DaySixView()
    }
}
