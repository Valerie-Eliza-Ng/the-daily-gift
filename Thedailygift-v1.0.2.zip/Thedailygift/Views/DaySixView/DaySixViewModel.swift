import Foundation
import SwiftUI

class DaySixViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
