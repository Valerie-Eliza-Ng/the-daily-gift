import Foundation
import SwiftUI

class Confirmation3ViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
