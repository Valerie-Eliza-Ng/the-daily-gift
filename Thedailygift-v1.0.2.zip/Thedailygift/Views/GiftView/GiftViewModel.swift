import Foundation
import SwiftUI

class GiftViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
