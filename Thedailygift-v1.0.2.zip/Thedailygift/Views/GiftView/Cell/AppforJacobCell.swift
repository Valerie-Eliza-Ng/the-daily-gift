import SwiftUI

struct AppforJacobCell: View {
    var body: some View {
        Image("img_appforjacob")
            .frame(width: getRelativeWidth(169.0), alignment: .leading)
            .resizable()
            .scaledToFit()
            .onTapGesture {}
    }
}

/* struct AppforJacobCell_Previews: PreviewProvider {

 static var previews: some View {
 			AppforJacobCell()
 }
 } */
