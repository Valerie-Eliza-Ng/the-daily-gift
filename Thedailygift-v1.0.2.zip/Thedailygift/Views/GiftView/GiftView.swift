import SwiftUI

struct GiftView: View {
    @StateObject var giftViewModel = GiftViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    Text(StringConstants.kLblOpenSesame)
                        .font(FontScheme.kAbelRegular(size: getRelativeHeight(36.0)))
                        .fontWeight(.regular)
                        .foregroundColor(ColorConstants.Red300)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: getRelativeWidth(186.0), height: getRelativeHeight(36.0),
                               alignment: .topLeading)
                        .padding(.top, getRelativeHeight(78.0))
                        .padding(.horizontal, getRelativeWidth(23.0))
                    Image("img_longerdesign1")
                        .resizable()
                        .frame(width: getRelativeWidth(330.0), height: getRelativeHeight(130.0),
                               alignment: .center)
                        .scaledToFit()
                        .clipped()
                        .padding(.top, getRelativeHeight(51.0))
                        .padding(.horizontal, getRelativeWidth(23.0))
                        .onTapGesture {
                            giftViewModel.nextScreen = "DayOneView"
                        }
                    ScrollView {
                        Grid(0 ..< 4, id: \.self) { index in
                            AppforJacobCell()
                        }
                    }
                    .gridStyle(StaggeredGridStyle(.vertical, tracks: 2, spacing: 7.0))
                    .padding(.top, getRelativeHeight(11.0))
                    .padding(.horizontal, getRelativeWidth(23.0))
                    Image("img_longerdesign_155x326")
                        .resizable()
                        .frame(width: getRelativeWidth(326.0), height: getRelativeHeight(155.0),
                               alignment: .center)
                        .scaledToFit()
                        .clipped()
                        .padding(.vertical, getRelativeHeight(10.0))
                        .padding(.horizontal, getRelativeWidth(23.0))
                        .onTapGesture {
                            giftViewModel.nextScreen = "DaySevenView"
                        }
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Gray50)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: DayFiveView(),
                                   tag: "DayFiveView",
                                   selection: $giftViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: DaySixView(),
                                   tag: "DaySixView",
                                   selection: $giftViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: DayOneView(),
                                   tag: "DayOneView",
                                   selection: $giftViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: DaySevenView(),
                                   tag: "DaySevenView",
                                   selection: $giftViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: DayTwoView(),
                                   tag: "DayTwoView",
                                   selection: $giftViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: DayThreeView(),
                                   tag: "DayThreeView",
                                   selection: $giftViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: DayFourView(),
                                   tag: "DayFourView",
                                   selection: $giftViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Gray50)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct GiftView_Previews: PreviewProvider {
    static var previews: some View {
        GiftView()
    }
}
