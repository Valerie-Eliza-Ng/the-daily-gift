import Foundation
import SwiftUI

class Confirmation1ViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
