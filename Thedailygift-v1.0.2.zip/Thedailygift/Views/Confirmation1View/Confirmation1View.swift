import SwiftUI

struct Confirmation1View: View {
    @StateObject var confirmation1ViewModel = Confirmation1ViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Image("img_appforjacob_358x375")
                            .resizable()
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(358.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(358.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(227.0))
                    VStack {
                        Button(action: {
                            confirmation1ViewModel.nextScreen = "GiftView"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgCountryRoads)
                                    .font(FontScheme.kManropeBold(size: getRelativeHeight(18.0)))
                                    .fontWeight(.bold)
                                    .padding(.horizontal, getRelativeWidth(14.0))
                                    .padding(.vertical, getRelativeHeight(12.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(290.0),
                                           height: getRelativeHeight(43.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Gray900))
                                    .padding(.horizontal, getRelativeWidth(43.0))
                            }
                        })
                        .frame(width: getRelativeWidth(290.0), height: getRelativeHeight(43.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Gray900))
                        .padding(.horizontal, getRelativeWidth(43.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(43.0),
                           alignment: .leading)
                    .padding(.vertical, getRelativeHeight(52.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Orange300)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: GiftView(),
                                   tag: "GiftView",
                                   selection: $confirmation1ViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Orange300)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct Confirmation1View_Previews: PreviewProvider {
    static var previews: some View {
        Confirmation1View()
    }
}
