import Foundation
import SwiftUI

class ConfirmationViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
