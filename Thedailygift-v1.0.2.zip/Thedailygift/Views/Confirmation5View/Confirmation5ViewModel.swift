import Foundation
import SwiftUI

class Confirmation5ViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
