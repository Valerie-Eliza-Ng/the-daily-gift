import Foundation
import SwiftUI

class DaySevenViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
