import SwiftUI

struct DaySevenView: View {
    @StateObject var daySevenViewModel = DaySevenViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Image("img_comboshape")
                            .resizable()
                            .frame(width: getRelativeWidth(20.0), height: getRelativeWidth(20.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.horizontal, getRelativeWidth(26.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(20.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(47.0))
                    VStack {
                        Text(StringConstants.kLblDay7)
                            .font(FontScheme.kAbelRegular(size: getRelativeHeight(36.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Red300)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(77.0), height: getRelativeHeight(36.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(51.0))
                        Text(StringConstants.kMsgDevote30Mins)
                            .font(FontScheme.kManropeRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Red300)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(274.0), height: getRelativeHeight(88.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(79.0))
                            .padding(.horizontal, getRelativeWidth(51.0))
                        Button(action: {
                            daySevenViewModel.nextScreen = "Confirmation6View"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblOhmmmmmm)
                                    .font(FontScheme.kManropeBold(size: getRelativeHeight(18.0)))
                                    .fontWeight(.bold)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(19.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(211.0),
                                           height: getRelativeHeight(56.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Red300))
                                    .padding(.top, getRelativeHeight(66.0))
                                    .padding(.horizontal, getRelativeWidth(51.0))
                            }
                        })
                        .frame(width: getRelativeWidth(211.0), height: getRelativeHeight(56.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Red300))
                        .padding(.top, getRelativeHeight(66.0))
                        .padding(.horizontal, getRelativeWidth(51.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(326.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(68.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Image("img_longerdesign_286x375")
                            .resizable()
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(286.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(286.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(64.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Gray900)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: Confirmation6View(),
                                   tag: "Confirmation6View",
                                   selection: $daySevenViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Gray900)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct DaySevenView_Previews: PreviewProvider {
    static var previews: some View {
        DaySevenView()
    }
}
