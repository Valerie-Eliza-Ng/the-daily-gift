import SwiftUI

struct Confirmation6View: View {
    @StateObject var confirmation6ViewModel = Confirmation6ViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack(alignment: .leading, spacing: 0) {
                    VStack(alignment: .trailing, spacing: 0) {
                        Image("img_appforjacob_360x317")
                            .resizable()
                            .frame(width: getRelativeWidth(317.0), height: getRelativeHeight(360.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.leading)
                            .padding(.leading)
                    }
                    .frame(width: getRelativeWidth(322.0), height: getRelativeHeight(360.0),
                           alignment: .trailing)
                    .padding(.leading, getRelativeWidth(43.0))
                    .padding(.trailing, getRelativeWidth(43.0))
                    VStack {
                        Button(action: {
                            confirmation6ViewModel.nextScreen = "GiftView"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgCountryRoads)
                                    .font(FontScheme.kManropeBold(size: getRelativeHeight(18.0)))
                                    .fontWeight(.bold)
                                    .padding(.horizontal, getRelativeWidth(14.0))
                                    .padding(.vertical, getRelativeHeight(12.0))
                                    .foregroundColor(ColorConstants.Gray900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(290.0),
                                           height: getRelativeHeight(43.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Orange300))
                                    .padding(.trailing, getRelativeWidth(32.0))
                            }
                        })
                        .frame(width: getRelativeWidth(290.0), height: getRelativeHeight(43.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Orange300))
                        .padding(.trailing, getRelativeWidth(32.0))
                    }
                    .frame(width: getRelativeWidth(322.0), height: getRelativeHeight(43.0),
                           alignment: .trailing)
                    .padding(.vertical, getRelativeHeight(124.0))
                    .padding(.leading, getRelativeWidth(43.0))
                    .padding(.trailing, getRelativeWidth(10.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Gray900)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: GiftView(),
                                   tag: "GiftView",
                                   selection: $confirmation6ViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Gray900)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct Confirmation6View_Previews: PreviewProvider {
    static var previews: some View {
        Confirmation6View()
    }
}
