import Foundation
import SwiftUI

class Confirmation6ViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
