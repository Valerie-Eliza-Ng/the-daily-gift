import Foundation
import SwiftUI

class OnboardViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
