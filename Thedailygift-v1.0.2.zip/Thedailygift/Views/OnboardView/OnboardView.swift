import SwiftUI

struct OnboardView: View {
    @StateObject var onboardViewModel = OnboardViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack {
                        Text(StringConstants.kLblTheDailyGift)
                            .font(FontScheme.kAbelRegular(size: getRelativeHeight(36.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Red300)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(172.0), height: getRelativeHeight(36.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(52.0))
                        Text(StringConstants.kMsgGivingIsAsGo)
                            .font(FontScheme.kManropeRegular(size: getRelativeHeight(20.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Yellow50)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(244.0), height: getRelativeHeight(43.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(23.0))
                            .padding(.horizontal, getRelativeWidth(52.0))
                        Button(action: {
                            onboardViewModel.nextScreen = "GiftView"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgSurpriseMeTod)
                                    .font(FontScheme.kManropeBold(size: getRelativeHeight(16.0)))
                                    .fontWeight(.bold)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(19.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(211.0),
                                           height: getRelativeHeight(56.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Red300))
                                    .padding(.top, getRelativeHeight(145.0))
                                    .padding(.horizontal, getRelativeWidth(52.0))
                            }
                        })
                        .frame(width: getRelativeWidth(211.0), height: getRelativeHeight(56.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Red300))
                        .padding(.top, getRelativeHeight(145.0))
                        .padding(.horizontal, getRelativeWidth(52.0))
                        Image("img_appforjacob1")
                            .resizable()
                            .frame(width: getRelativeWidth(351.0), height: getRelativeHeight(348.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.top, getRelativeHeight(43.0))
                    }
                    .frame(width: getRelativeWidth(351.0), height: getRelativeHeight(695.0),
                           alignment: .leading)
                    .background(ColorConstants.Gray900)
                }
                .frame(width: getRelativeWidth(351.0), alignment: .topLeading)
                .background(ColorConstants.Gray900)
                .padding(.top, getRelativeHeight(145.0))
                .padding(.horizontal, getRelativeWidth(12.0))
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: GiftView(),
                                   tag: "GiftView",
                                   selection: $onboardViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Gray900)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
        .onAppear {
            onboardViewModel.nextScreen = "GiftView"
        }
    }
}

struct OnboardView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardView()
    }
}
