import Foundation
import SwiftUI

class DayThreeViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
