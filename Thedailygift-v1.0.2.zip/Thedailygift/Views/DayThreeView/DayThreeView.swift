import SwiftUI

struct DayThreeView: View {
    @StateObject var dayThreeViewModel = DayThreeViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    Image("img_comboshape")
                        .resizable()
                        .frame(width: getRelativeWidth(20.0), height: getRelativeWidth(20.0),
                               alignment: .center)
                        .scaledToFit()
                        .clipped()
                        .padding(.leading, getRelativeWidth(26.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Image("img_appforjacob_347x286")
                            .resizable()
                            .frame(width: getRelativeWidth(286.0), height: getRelativeHeight(347.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.leading, getRelativeWidth(10.0))
                        Text(StringConstants.kLblDay3)
                            .font(FontScheme.kAbelRegular(size: getRelativeHeight(36.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Orange300)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(77.0), height: getRelativeHeight(36.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(96.0))
                            .padding(.horizontal, getRelativeWidth(93.0))
                        Text(StringConstants.kMsgStartANewBoo)
                            .font(FontScheme.kManropeRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Orange300)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(267.0), height: getRelativeHeight(25.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(67.0))
                            .padding(.trailing, getRelativeWidth(10.0))
                        Button(action: {
                            dayThreeViewModel.nextScreen = "Confirmation3View"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgDo2PagesCoun)
                                    .font(FontScheme.kManropeBold(size: getRelativeHeight(18.0)))
                                    .fontWeight(.bold)
                                    .padding(.horizontal, getRelativeWidth(15.0))
                                    .padding(.vertical, getRelativeHeight(18.0))
                                    .foregroundColor(ColorConstants.Gray900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(211.0),
                                           height: getRelativeHeight(56.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Orange300))
                                    .padding(.top, getRelativeHeight(86.0))
                                    .padding(.horizontal, getRelativeWidth(28.0))
                            }
                        })
                        .frame(width: getRelativeWidth(211.0), height: getRelativeHeight(56.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Orange300))
                        .padding(.top, getRelativeHeight(86.0))
                        .padding(.horizontal, getRelativeWidth(28.0))
                    }
                    .frame(width: getRelativeWidth(319.0), height: getRelativeHeight(715.0),
                           alignment: .top)
                    .padding(.leading, getRelativeWidth(10.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Gray900)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: Confirmation3View(),
                                   tag: "Confirmation3View",
                                   selection: $dayThreeViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Gray900)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct DayThreeView_Previews: PreviewProvider {
    static var previews: some View {
        DayThreeView()
    }
}
