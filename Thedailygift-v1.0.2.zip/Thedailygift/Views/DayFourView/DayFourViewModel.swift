import Foundation
import SwiftUI

class DayFourViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
