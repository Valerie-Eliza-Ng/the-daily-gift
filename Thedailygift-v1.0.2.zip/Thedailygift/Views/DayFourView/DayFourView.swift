import SwiftUI

struct DayFourView: View {
    @StateObject var dayFourViewModel = DayFourViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Image("img_comboshape")
                            .resizable()
                            .frame(width: getRelativeWidth(20.0), height: getRelativeWidth(20.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.horizontal, getRelativeWidth(26.0))
                    }
                    .frame(width: getRelativeWidth(330.0), height: getRelativeHeight(20.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(47.0))
                    .padding(.trailing, getRelativeWidth(10.0))
                    VStack {
                        Text(StringConstants.kLblDay4)
                            .font(FontScheme.kAbelRegular(size: getRelativeHeight(36.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Red300)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(73.0), height: getRelativeHeight(36.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(70.0))
                        Text(StringConstants.kMsgHaveAFruitTh)
                            .font(FontScheme.kManropeRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Red300)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(231.0), height: getRelativeHeight(50.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(66.0))
                            .padding(.leading, getRelativeWidth(70.0))
                            .padding(.trailing, getRelativeWidth(28.0))
                        Button(action: {
                            dayFourViewModel.nextScreen = "Confirmation4View"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgTriedItLike)
                                    .font(FontScheme.kManropeBold(size: getRelativeHeight(18.0)))
                                    .fontWeight(.bold)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(18.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(211.0),
                                           height: getRelativeHeight(56.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Red300))
                                    .padding(.top, getRelativeHeight(80.0))
                                    .padding(.leading, getRelativeWidth(70.0))
                                    .padding(.trailing, getRelativeWidth(37.0))
                            }
                        })
                        .frame(width: getRelativeWidth(211.0), height: getRelativeHeight(56.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Red300))
                        .padding(.top, getRelativeHeight(80.0))
                        .padding(.leading, getRelativeWidth(70.0))
                        .padding(.trailing, getRelativeWidth(37.0))
                    }
                    .frame(width: getRelativeWidth(330.0), height: getRelativeHeight(290.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(31.0))
                    .padding(.trailing, getRelativeWidth(10.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Image("img_appforjacob_349x330")
                            .resizable()
                            .frame(width: getRelativeWidth(330.0), height: getRelativeHeight(349.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                    }
                    .frame(width: getRelativeWidth(330.0), height: getRelativeHeight(349.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(74.0))
                    .padding(.trailing, getRelativeWidth(10.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Gray900)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: Confirmation4View(),
                                   tag: "Confirmation4View",
                                   selection: $dayFourViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Gray900)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct DayFourView_Previews: PreviewProvider {
    static var previews: some View {
        DayFourView()
    }
}
