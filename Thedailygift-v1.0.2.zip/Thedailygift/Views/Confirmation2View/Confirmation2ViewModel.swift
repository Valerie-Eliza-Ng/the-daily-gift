import Foundation
import SwiftUI

class Confirmation2ViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
