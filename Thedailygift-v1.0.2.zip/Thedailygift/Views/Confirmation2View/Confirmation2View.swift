import SwiftUI

struct Confirmation2View: View {
    @StateObject var confirmation2ViewModel = Confirmation2ViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack(alignment: .leading, spacing: 0) {
                    VStack(alignment: .leading, spacing: 0) {
                        Image("img_comboshape")
                            .resizable()
                            .frame(width: getRelativeWidth(20.0), height: getRelativeWidth(20.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.trailing)
                    }
                    .frame(width: getRelativeWidth(327.0), height: getRelativeHeight(20.0),
                           alignment: .center)
                    .padding(.top, getRelativeHeight(47.0))
                    .padding(.horizontal, getRelativeWidth(24.0))
                    VStack {
                        Image("img_appforjacob_401x327")
                            .resizable()
                            .frame(width: getRelativeWidth(327.0), height: getRelativeHeight(401.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                        Button(action: {
                            confirmation2ViewModel.nextScreen = "GiftView"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgCountryRoads)
                                    .font(FontScheme.kManropeBold(size: getRelativeHeight(18.0)))
                                    .fontWeight(.bold)
                                    .padding(.horizontal, getRelativeWidth(14.0))
                                    .padding(.vertical, getRelativeHeight(12.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(290.0),
                                           height: getRelativeHeight(43.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Gray900))
                                    .padding(.top, getRelativeHeight(98.0))
                                    .padding(.leading, getRelativeWidth(24.0))
                                    .padding(.trailing, getRelativeWidth(13.0))
                            }
                        })
                        .frame(width: getRelativeWidth(290.0), height: getRelativeHeight(43.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Gray900))
                        .padding(.top, getRelativeHeight(98.0))
                        .padding(.leading, getRelativeWidth(24.0))
                        .padding(.trailing, getRelativeWidth(13.0))
                    }
                    .frame(width: getRelativeWidth(327.0), height: getRelativeHeight(542.0),
                           alignment: .center)
                    .padding(.vertical, getRelativeHeight(152.0))
                    .padding(.horizontal, getRelativeWidth(24.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Red300)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: GiftView(),
                                   tag: "GiftView",
                                   selection: $confirmation2ViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Red300)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct Confirmation2View_Previews: PreviewProvider {
    static var previews: some View {
        Confirmation2View()
    }
}
