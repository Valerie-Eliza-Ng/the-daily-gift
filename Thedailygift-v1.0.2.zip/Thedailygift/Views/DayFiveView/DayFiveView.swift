import SwiftUI

struct DayFiveView: View {
    @StateObject var dayFiveViewModel = DayFiveViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Image("img_comboshape")
                            .resizable()
                            .frame(width: getRelativeWidth(20.0), height: getRelativeWidth(20.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.trailing)
                    }
                    .frame(width: getRelativeWidth(349.0), height: getRelativeHeight(20.0),
                           alignment: .trailing)
                    .padding(.top, getRelativeHeight(47.0))
                    .padding(.leading, getRelativeWidth(10.0))
                    VStack {
                        Text(StringConstants.kLblDay5)
                            .font(FontScheme.kAbelRegular(size: getRelativeHeight(36.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Gray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(77.0), height: getRelativeHeight(36.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(48.0))
                        Text(StringConstants.kMsgBeAHeroToA)
                            .font(FontScheme.kManropeRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(227.0), height: getRelativeHeight(78.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(55.0))
                            .padding(.horizontal, getRelativeWidth(48.0))
                        Button(action: {
                            dayFiveViewModel.nextScreen = "Confirmation5View"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgHungryFriendF)
                                    .font(FontScheme.kManropeBold(size: getRelativeHeight(18.0)))
                                    .fontWeight(.bold)
                                    .padding(.horizontal, getRelativeWidth(26.0))
                                    .padding(.vertical, getRelativeHeight(18.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(211.0),
                                           height: getRelativeHeight(56.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Red300))
                                    .padding(.top, getRelativeHeight(70.0))
                                    .padding(.horizontal, getRelativeWidth(48.0))
                            }
                        })
                        .frame(width: getRelativeWidth(211.0), height: getRelativeHeight(56.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Red300))
                        .padding(.top, getRelativeHeight(70.0))
                        .padding(.horizontal, getRelativeWidth(48.0))
                    }
                    .frame(width: getRelativeWidth(349.0), height: getRelativeHeight(296.0),
                           alignment: .trailing)
                    .padding(.top, getRelativeHeight(42.0))
                    .padding(.leading, getRelativeWidth(10.0))
                    VStack(alignment: .trailing, spacing: 0) {
                        Image("img_appforjacob_329x337")
                            .resizable()
                            .frame(width: getRelativeWidth(337.0), height: getRelativeHeight(329.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.leading)
                            .padding(.leading)
                    }
                    .frame(width: getRelativeWidth(349.0), height: getRelativeHeight(329.0),
                           alignment: .trailing)
                    .padding(.top, getRelativeHeight(77.0))
                    .padding(.leading, getRelativeWidth(10.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.OrangeA200)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: Confirmation5View(),
                                   tag: "Confirmation5View",
                                   selection: $dayFiveViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.OrangeA200)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct DayFiveView_Previews: PreviewProvider {
    static var previews: some View {
        DayFiveView()
    }
}
