import Foundation
import SwiftUI

class DayFiveViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
