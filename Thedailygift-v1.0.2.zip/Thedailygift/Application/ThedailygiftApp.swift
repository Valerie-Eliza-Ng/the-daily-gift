//
//  ThedailygiftApp.swift
//  Thedailygift

import SwiftUI

@main
struct ThedailygiftApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            OnboardView()
        }
    }
}
